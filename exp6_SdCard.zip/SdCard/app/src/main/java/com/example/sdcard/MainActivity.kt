package com.example.sdcard

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Environment
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.io.File
import java.io.FileOutputStream
import java.io.IOException

class MainActivity : AppCompatActivity() {
    private lateinit var registerNumberEditText: EditText
    private lateinit var nameEditText: EditText
    private lateinit var cgpaEditText: EditText
    private lateinit var saveButton: Button
    private lateinit var loadButton: Button

    private val STORAGE_PERMISSION_CODE = 100

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Initialize UI components
        registerNumberEditText = findViewById(R.id.editTextRegisterNumber)
        nameEditText = findViewById(R.id.editTextName)
        cgpaEditText = findViewById(R.id.editTextCGPA)
        saveButton = findViewById(R.id.buttonSave)
        loadButton = findViewById(R.id.buttonLoad)

        // Request storage permissions
        requestStoragePermission()

        // Set click listeners
        saveButton.setOnClickListener {
            saveDataToSD()
        }

        loadButton.setOnClickListener {
            loadDataFromSD()
        }
    }

    private fun requestStoragePermission() {
        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.WRITE_EXTERNAL_STORAGE
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(
                    Manifest.permission.WRITE_EXTERNAL_STORAGE,
                    Manifest.permission.READ_EXTERNAL_STORAGE
                ),
                STORAGE_PERMISSION_CODE
            )
        }
    }

    private fun saveDataToSD() {
        // Validate inputs
        val registerNumber = registerNumberEditText.text.toString().trim()
        val name = nameEditText.text.toString().trim()
        val cgpa = cgpaEditText.text.toString().trim()

        if (registerNumber.isEmpty() || name.isEmpty() || cgpa.isEmpty()) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show()
            return
        }

        try {
            // Try multiple storage options for emulator compatibility
            val file = try {
                // Option 1: Using app-specific external storage (works on most emulators)
                val appDir = getExternalFilesDir(null)
                val dir = File(appDir, "SDCardApp")
                if (!dir.exists()) {
                    dir.mkdirs()
                }
                File(dir, "$registerNumber.txt")
            } catch (e: Exception) {
                // Option 2: Using legacy external storage as fallback
                val dir = File(Environment.getExternalStorageDirectory(), "SDCardApp")
                if (!dir.exists()) {
                    dir.mkdirs()
                }
                File(dir, "$registerNumber.txt")
            }

            // Create file
            val fileOutputStream = FileOutputStream(file)
            val data = "Register Number: $registerNumber\nName: $name\nCGPA: $cgpa"

            fileOutputStream.write(data.toByteArray())
            fileOutputStream.close()

            Toast.makeText(this, "Data saved successfully to ${file.absolutePath}", Toast.LENGTH_LONG).show()

            // Clear fields after saving
            registerNumberEditText.text.clear()
            nameEditText.text.clear()
            cgpaEditText.text.clear()

        } catch (e: IOException) {
            e.printStackTrace()
            Toast.makeText(this, "Error saving data: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun loadDataFromSD() {
        val registerNumber = registerNumberEditText.text.toString().trim()

        if (registerNumber.isEmpty()) {
            Toast.makeText(this, "Please enter a register number", Toast.LENGTH_SHORT).show()
            return
        }

        try {
            // Try to find the file in multiple storage locations
            val file = findDataFile(registerNumber)

            if (file == null || !file.exists()) {
                Toast.makeText(this, "No data found for this register number", Toast.LENGTH_SHORT).show()
                return
            }

            val fileContent = file.readText()
            val lines = fileContent.split("\n")

            // Parse the data
            for (line in lines) {
                when {
                    line.startsWith("Name:") -> {
                        val name = line.substring(line.indexOf(":") + 1).trim()
                        nameEditText.setText(name)
                    }
                    line.startsWith("CGPA:") -> {
                        val cgpa = line.substring(line.indexOf(":") + 1).trim()
                        cgpaEditText.setText(cgpa)
                    }
                }
            }

            Toast.makeText(this, "Data loaded successfully from ${file.absolutePath}", Toast.LENGTH_SHORT).show()

        } catch (e: IOException) {
            e.printStackTrace()
            Toast.makeText(this, "Error loading data: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun findDataFile(registerNumber: String): File? {
        // Try app-specific external storage first
        val appDir = getExternalFilesDir(null)
        val appSpecificDir = File(appDir, "SDCardApp")
        var file = File(appSpecificDir, "$registerNumber.txt")

        if (file.exists()) {
            return file
        }

        // Try legacy external storage
        try {
            val externalDir = File(Environment.getExternalStorageDirectory(), "SDCardApp")
            file = File(externalDir, "$registerNumber.txt")
            if (file.exists()) {
                return file
            }
        } catch (e: Exception) {
            // Ignore and continue to other options
        }

        // Try cache directory as last resort
        val cacheDir = File(cacheDir, "SDCardApp")
        if (!cacheDir.exists()) {
            cacheDir.mkdirs()
        }
        file = File(cacheDir, "$registerNumber.txt")
        if (file.exists()) {
            return file
        }

        return null
    }

    // Checks if external storage is available for read and write
    private fun isExternalStorageWritable(): Boolean {
        return Environment.getExternalStorageState() == Environment.MEDIA_MOUNTED
    }

    // Checks if external storage is available to at least read
    private fun isExternalStorageReadable(): Boolean {
        return Environment.getExternalStorageState() in
                setOf(Environment.MEDIA_MOUNTED, Environment.MEDIA_MOUNTED_READ_ONLY)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == STORAGE_PERMISSION_CODE) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Storage permission granted", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Storage permission denied", Toast.LENGTH_SHORT).show()
            }
        }
    }
}