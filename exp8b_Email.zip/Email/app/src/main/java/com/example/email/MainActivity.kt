package com.example.email

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var toEditText: EditText
    private lateinit var subjectEditText: EditText
    private lateinit var messageEditText: EditText
    private lateinit var sendButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Initialize UI components
        toEditText = findViewById(R.id.to_edit_text)
        subjectEditText = findViewById(R.id.subject_edit_text)
        messageEditText = findViewById(R.id.message_edit_text)
        sendButton = findViewById(R.id.send_button)

        // Set up send button click listener
        sendButton.setOnClickListener {
            sendEmail()
        }
    }

    private fun sendEmail() {
        val recipient = toEditText.text.toString().trim()
        val subject = subjectEditText.text.toString().trim()
        val message = messageEditText.text.toString().trim()

        // Basic validation
        if (recipient.isEmpty()) {
            Toast.makeText(this, "Please enter recipient email", Toast.LENGTH_SHORT).show()
            return
        }

        try {
            // Try first with ACTION_SENDTO (preferred way for email)
            val emailIntent = Intent(Intent.ACTION_SENDTO).apply {
                data = Uri.parse("mailto:") // only email apps should handle this
                putExtra(Intent.EXTRA_EMAIL, arrayOf(recipient))
                putExtra(Intent.EXTRA_SUBJECT, subject)
                putExtra(Intent.EXTRA_TEXT, message)
            }

            // Check if there's a matching activity
            if (emailIntent.resolveActivity(packageManager) != null) {
                startActivity(emailIntent)
                return
            }

            // Fallback to ACTION_SEND (more general, will show more apps)
            val sendIntent = Intent(Intent.ACTION_SEND).apply {
                type = "message/rfc822" // email mime type
                putExtra(Intent.EXTRA_EMAIL, arrayOf(recipient))
                putExtra(Intent.EXTRA_SUBJECT, subject)
                putExtra(Intent.EXTRA_TEXT, message)
            }

            // Use createChooser to always show options even if default is set
            startActivity(Intent.createChooser(sendIntent, "Send email using..."))

        } catch (e: Exception) {
            // Show more detailed error message
            Toast.makeText(
                this,
                "No email app available. Error: ${e.message}",
                Toast.LENGTH_LONG
            ).show()
            e.printStackTrace()
        }
    }
}